/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-G10
 */

#ifndef cyhc_dsp_core0__
#define cyhc_dsp_core0__



#endif /* cyhc_dsp_core0__ */ 
