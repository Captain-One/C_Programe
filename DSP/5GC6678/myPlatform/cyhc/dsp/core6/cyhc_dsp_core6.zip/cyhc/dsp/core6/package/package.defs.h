/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-F07
 */

#ifndef cyhc_dsp_core6__
#define cyhc_dsp_core6__



#endif /* cyhc_dsp_core6__ */ 
