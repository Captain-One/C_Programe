/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-F07
 */

#ifndef cyhc_dsp_core4__
#define cyhc_dsp_core4__



#endif /* cyhc_dsp_core4__ */ 
